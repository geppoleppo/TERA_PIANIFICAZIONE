// App.js - Modificato per utilizzare dati statici
import React, { useState, useRef } from 'react';
import './App.css';
import Gantt from './components/Gantt';
import Gantt2 from './components/Gantt2';
import Sidebar from './sidebar/Sidebar';

const App = () => {
  const [projectResources, setProjectResources] = useState([
    { resourceId: 1, resourceName: 'Pluto 1', color: '#FF0000', resourceGroup: 'merda' },
    { resourceId: 2, resourceName: 'Pippo 2', color: '#00FF00', resourceGroup:'cacca' },
    { resourceId: 3, resourceName: 'unico3', color: '#00FF00', resourceGroup:'cacca' }, 
  ]);



  const [events, setEvents] = useState([
    {
      Id: 1,
      Subject: 'Evento 1',
      StartTime: new Date('2025-01-01'),
      EndTime: new Date('2025-01-02'),
      CommessaId: 1,
      CategoryColor: '#FF0000',
     
    },
    {
      Id: 2,
      Subject: 'Evento 2',
      StartTime: new Date('2025-01-03'),
      EndTime: new Date('2025-01-04'),
      CommessaId: 2,
      CategoryColor: '#00FF00',
    },
    {
      Id: 3,
      Subject: 'Evento 3',
      StartTime: new Date('2025-01-03'),
      EndTime: new Date('2025-01-04'),
      CommessaId: 2,
      CategoryColor: '#00FF00',
     
    },
  ]);

  const ganttRef = useRef(null);

  const handleUpdateEvent = (updatedEvent) => {
    setEvents((prevEvents) =>
      prevEvents.map((event) => (event.Id === updatedEvent.Id ? { ...event, ...updatedEvent } : event))
    );
    if (ganttRef.current) ganttRef.current.refresh();
  };

  const handleDeleteEvent = (eventId) => {
    setEvents((prevEvents) => prevEvents.filter((event) => event.Id !== eventId));
    if (ganttRef.current) ganttRef.current.refresh();
  };

  const handleSaveEvent = (newEvent) => {
    setEvents((prevEvents) => [...prevEvents, { ...newEvent, Id: prevEvents.length + 1 }]);
    if (ganttRef.current) ganttRef.current.refresh();
  };

  return (
    <div className="App">
      <Sidebar
        setProjectResources={setProjectResources}
        projectResources={projectResources}
      />

      <Gantt
        ganttData={events}
        projectResources={projectResources}
        onUpdateEvent={handleUpdateEvent}
        onDeleteEvent={handleDeleteEvent}
        onSaveEvent={handleSaveEvent}
        ref={ganttRef}
      />
      <Gantt2
        ganttData={events}
        projectResources={projectResources}
        onUpdateEvent={handleUpdateEvent}
        onDeleteEvent={handleDeleteEvent}
        onSaveEvent={handleSaveEvent}
        ref={ganttRef}
      />

    </div>
  );
};

export default App;
